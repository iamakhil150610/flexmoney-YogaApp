from django.apps import AppConfig


class YogawebConfig(AppConfig):
    name = 'yogaweb'
